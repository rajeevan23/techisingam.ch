#!/bin/zsh

# Define variables
appname="System Reboot"
logandmetadir="/Library/Application Support/Microsoft/IntuneScripts/SystemReboot"
log="$logandmetadir/$appname.log"

echo "progress: 100" >>/var/tmp/dialog.log
echo "progresstext: Finalizing and Rebooting" >>/var/tmp/dialog.log
echo "icon: /Library/Application Support/SwiftDialogResources/icons/settings.png" >>/var/tmp/dialog.log

# Function to update the splash screen
function updateSplashScreen() {
    if [[ -e "/Library/Application Support/Dialog/Dialog.app/Contents/MacOS/Dialog" ]]; then
        echo "$(date) | Updating Swift Dialog monitor for [$appname] to [$1]"
        echo listitem: title: $appname, status: $1, statustext: $2 >>/var/tmp/dialog.log
    fi
}

# Function to start logging
function startLog() {
    if [[ ! -d "$logandmetadir" ]]; then
        echo "$(date) | Creating [$logandmetadir] to store logs"
        mkdir -p "$logandmetadir"
    fi
    exec > >(tee -a "$log") 2>&1
}

# Start logging
startLog

echo "$(date) | Starting final system update and reboot process"

# Update splash screen to show final updates are being installed
updateSplashScreen wait "Installing final updates"

# Install any remaining updates that require a restart
softwareupdate -ia --restart

# If the above command doesn't restart (in case there were no updates), we'll reboot anyway
echo "$(date) | Initiating system reboot"
shutdown -r now

exit 0
