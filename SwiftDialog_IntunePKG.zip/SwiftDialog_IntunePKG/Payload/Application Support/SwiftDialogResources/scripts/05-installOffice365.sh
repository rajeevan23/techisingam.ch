#!/bin/bash

# Script to install Microsoft Office 365

# User Defined variables
appname="Microsoft Office 365"
logandmetadir="/Library/Application Support/Microsoft/IntuneScripts/installOffice365"
log="$logandmetadir/$appname.log"

echo "progress: 50" >>/var/tmp/dialog.log
echo "progresstext: Installing Microsoft Office 365" >>/var/tmp/dialog.log
echo "icon: /Library/Application Support/SwiftDialogResources/icons/Office365.png" >>/var/tmp/dialog.log

# URL for the Office 365 package
OFFICE_URL="https://go.microsoft.com/fwlink/?linkid=525133"

# Temporary location to save the downloaded package
TEMP_PKG="/tmp/Office365.pkg"

# Function to update the Splash Screen status
function updateSplashScreen() {
    # Is Swift Dialog present
    if [[ -e "/Library/Application Support/Dialog/Dialog.app/Contents/MacOS/Dialog" ]]; then
        echo "$(date) | Updating Swift Dialog monitor for [$appname] to [$1]"
        echo "listitem: title: $appname, status: $1, statustext: $2" >>/var/tmp/dialog.log
    fi
}

# Function to start logging
function startLog() {
    if [[ ! -d "$logandmetadir" ]]; then
        echo "$(date) | Creating [$logandmetadir] to store logs"
        mkdir -p "$logandmetadir"
    fi
    exec > >(tee -a "$log") 2>&1
}

# Start logging
startLog

echo ""
echo "##############################################################"
echo "# $(date) | Logging install of [$appname] to [$log]"
echo "############################################################"
echo ""

# Download the Office 365 package
echo "$(date) | Downloading Microsoft Office 365..."
updateSplashScreen wait "Downloading"
curl -L "$OFFICE_URL" -o "$TEMP_PKG"

# Check if download was successful
if [ ! -f "$TEMP_PKG" ]; then
    echo "$(date) | Failed to download Office 365 package."
    updateSplashScreen fail "Download Failed"
    exit 1
fi

# Install the package
echo "$(date) | Installing Microsoft Office 365..."
updateSplashScreen wait "Installing"
sudo installer -pkg "$TEMP_PKG" -target /

# Check installation status
if [ $? -eq 0 ]; then
    echo "$(date) | Microsoft Office 365 installed successfully."
    updateSplashScreen success "Installed"
else
    echo "$(date) | Failed to install Microsoft Office 365."
    updateSplashScreen fail "Installation Failed"
    exit 1
fi

# Clean up the temporary file
rm "$TEMP_PKG"

echo "$(date) | Installation process completed."
